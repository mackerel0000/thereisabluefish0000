X 재게시물 반응 알림 필터 v7_pc chrome

1 ZIP을 PC에서 압축 해제
2 Chrome에서 chrome://extensions 입력
3 우측 상단 개발자 모드 켜기
4 압축해제된 확장 프로그램을 로드 클릭
5 압축 해제한 x-repost-notification-filter 폴더 선택
6 X를 새로고침
7 x.com/notifications에서 확인

알림창에서 'liked your repost' 또는 'reposted your repost'가 포함된 행을 숨깁니다.
뒤에 붙는 상대시간/날짜는 검사하지 않습니다.
누가 재게시했는지, 원본/재게시 여부, 네트워크 응답은 검사하지 않습니다.
알림 배지 숫자는 변경하지 않습니다.
