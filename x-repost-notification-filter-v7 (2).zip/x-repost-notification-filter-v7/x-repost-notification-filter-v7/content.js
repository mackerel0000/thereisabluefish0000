(() => {
  'use strict';
  const TARGET_PHRASES = ['liked your repost','reposted your repost'];
  const ROW_SELECTOR = '[data-testid="notification"],[data-testid="cellInnerDiv"],article,[role="article"]';
  let observer = null, active = false, lastRoute = location.href;
  const isNotificationsPage = () => /^\/notifications(?:\/|$)/.test(location.pathname);
  const normalize = s => (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const containsTargetPhrase = text => { const t = normalize(text); return TARGET_PHRASES.some(p => t.includes(p)); };
  const hideRow = row => { if (row?.nodeType === Node.ELEMENT_NODE) row.setAttribute('data-x-repost-filter-v7','hidden'); };
  function scan(root=document) {
    if (!active || !isNotificationsPage()) return;
    if (root.querySelectorAll) for (const row of root.querySelectorAll(ROW_SELECTOR)) if (containsTargetPhrase(row.innerText || row.textContent || '')) hideRow(row);
    const treeRoot = root.nodeType === Node.ELEMENT_NODE ? root : document;
    const walker = document.createTreeWalker(treeRoot, NodeFilter.SHOW_TEXT, {acceptNode(node) {
      return TARGET_PHRASES.some(p => normalize(node.nodeValue).includes(p)) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }});
    const hits=[]; let n; while ((n=walker.nextNode())) hits.push(n);
    for (const textNode of hits) {
      let el=textNode.parentElement; if(!el) continue;
      const row=el.closest(ROW_SELECTOR); if(row) { hideRow(row); continue; }
      for(let i=0;i<6 && el.parentElement;i++){ el=el.parentElement; const txt=normalize(el.innerText||el.textContent||''); if(txt.length>0&&txt.length<1000&&containsTargetPhrase(txt)){hideRow(el);break;} }
    }
  }
  function start(){ if(active)return; active=true; observer?.disconnect(); observer=new MutationObserver(ms=>{for(const m of ms)for(const n of m.addedNodes)if(n.nodeType===Node.ELEMENT_NODE)scan(n);}); observer.observe(document.documentElement,{childList:true,subtree:true}); scan(document); }
  function stop(){ active=false; observer?.disconnect(); observer=null; document.querySelectorAll('[data-x-repost-filter-v7]').forEach(el=>el.removeAttribute('data-x-repost-filter-v7')); }
  function checkRoute(){const cur=location.href;if(cur===lastRoute)return;lastRoute=cur;if(isNotificationsPage())start();else stop();}
  const ps=history.pushState; history.pushState=function(...a){const r=ps.apply(this,a);setTimeout(checkRoute,0);return r;};
  const rs=history.replaceState; history.replaceState=function(...a){const r=rs.apply(this,a);setTimeout(checkRoute,0);return r;};
  addEventListener('popstate',()=>setTimeout(checkRoute,0)); addEventListener('hashchange',()=>setTimeout(checkRoute,0));
  setInterval(checkRoute,500); if(isNotificationsPage())start();
})();
