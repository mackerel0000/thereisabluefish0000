X 재게시물 반응 알림 필터 v7 - iPhone/iPad Safari용

[무엇을 하는 확장 프로그램인가요?]
iPhone/iPad의 Safari에서 x.com의 알림창을 열었을 때 다음 문구가 포함된 알림 행을 숨깁니다.

- liked your repost
- reposted your repost

예:
- 홍차한잔 liked your repost · 27m  -> 숨김
- 공 reposted your repost · 2h      -> 숨김
- 공 reposted your repost · Oct 1   -> 숨김

날짜/시간은 검사하지 않습니다.
누가 재게시했는지, 트윗 작성자가 누구인지, 원본/재게시 여부를 판별하지 않습니다.
알림 배지 숫자는 변경하지 않습니다.

[중요: iPhone/iPad Safari는 ZIP을 직접 설치하지 않습니다]
Apple의 Safari Web Extension은 iOS 앱에 포함되는 형태로 설치/배포됩니다.
따라서 이 ZIP은 'Safari Web Extension Packager에 넣는 확장 프로그램 파일'입니다.
ZIP을 iPhone에서 Safari로 열기만 해서 바로 설치할 수 있는 파일은 아닙니다.

[가장 쉬운 공식 방법: App Store Connect의 Safari Web Extension Packager]
현재 Apple은 App Store Connect에서 웹 브라우저만으로 Safari Web Extension을 패키징할 수 있는 Safari Web Extension Packager를 제공합니다.
다만 Apple Developer Program 등록이 필요합니다.

1. Apple Developer Program에 가입합니다.
2. App Store Connect에 로그인합니다.
3. Apps에서 + -> New App을 선택합니다.
4. 플랫폼에서 iOS를 선택합니다.
5. 앱 이름과 Bundle ID 등을 입력해 앱 레코드를 만듭니다.
6. 생성한 앱에서 Xcode Cloud 영역의 Safari Web Extension Packager를 찾습니다.
7. Upload를 눌러 이 ZIP의 '확장 프로그램 파일 전체'를 업로드합니다.
   - manifest.json
   - content.js
   - style.css
   - 기타 리소스
8. Apple의 Packager가 iOS 앱/확장 프로그램 빌드를 만듭니다.
9. TestFlight로 본인 기기에 설치해 테스트할 수 있습니다.
10. iPhone/iPad에서 설정 -> Safari -> 확장 프로그램으로 이동합니다.
11. 'X 재게시물 반응 알림 필터 v7'을 켭니다.
12. x.com을 Safari로 열고 로그인합니다.
13. x.com/notifications 로 이동합니다.
14. 'liked your repost' 또는 'reposted your repost'가 포함된 알림이 사라지는지 확인합니다.

[Mac이 있다면]
Mac의 Xcode를 이용해 이 확장 프로그램 파일을 Safari Web Extension 프로젝트로 패키징할 수도 있습니다.
Apple의 safari-web-extension-packager 도구로 기존 웹 확장 프로그램을 Safari Web Extension 프로젝트로 변환할 수 있습니다.

예시 명령:
xcrun safari-web-extension-packager /path/to/this-extension --ios-only

생성된 Xcode 프로젝트를 열고 Signing & Capabilities에서 본인의 Apple Developer Team을 선택한 뒤 iOS 기기에 빌드합니다.
처음 사용하는 경우에는 Xcode의 서명(Signing) 설정이 필요합니다.

[설치 후 테스트]
1. iPhone/iPad에서 Safari를 엽니다.
2. x.com/notifications 로 이동합니다.
3. '공 reposted your repost · Oct 1' 같은 알림이 사라지는지 확인합니다.
4. 일반 'liked your post'나 멘션 알림은 남아 있는지 확인합니다.
5. 알림 페이지를 스크롤해 새로 나타나는 알림에도 적용되는지 확인합니다.

[문제 해결]
- Safari 확장 프로그램이 보이지 않으면 설정 -> Safari -> 확장 프로그램에서 활성화 여부를 확인합니다.
- 확장 프로그램이 켜져 있어도 x.com에서 작동하지 않으면 Safari의 해당 사이트 권한에서 x.com에 대한 접근을 허용해야 할 수 있습니다.
- X가 웹사이트의 HTML 구조를 변경하면 이후 버전에서 필터를 수정해야 할 수 있습니다.
