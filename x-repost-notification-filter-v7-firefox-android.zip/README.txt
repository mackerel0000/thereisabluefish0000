X 재게시물 반응 알림 필터 v7 - Firefox Android용

[무엇을 하는 확장 프로그램인가요?]
Firefox Android에서 x.com의 알림창을 열었을 때 다음 문구가 포함된 알림 행을 숨깁니다.

- liked your repost
- reposted your repost

예:
- 홍차한잔 liked your repost · 27m  -> 숨김
- 공 reposted your repost · 2h      -> 숨김
- 공 reposted your repost · Oct 1   -> 숨김

날짜/시간은 검사하지 않습니다.
누가 재게시했는지, 트윗 작성자가 누구인지, 원본/재게시 여부를 판별하지 않습니다.
알림 배지 숫자는 변경하지 않습니다.

[중요: Firefox Android에서 설치하는 방법]

Firefox Android는 데스크톱 Firefox처럼 임의의 ZIP 파일을 바로 확장 프로그램으로 설치하는 방식이 아닙니다.
Mozilla의 현재 공식 안내에 따르면 Android용 Firefox 확장 프로그램은 Firefox의 확장 기능 관리자 또는 addons.mozilla.org/android(AMO)에서 설치합니다.

따라서 이 ZIP은 'Firefox Android용 확장 프로그램 원본 파일'입니다.
휴대폰에서 바로 ZIP을 여는 것만으로는 설치되지 않습니다.

가장 쉬운 방법
1. Firefox Android를 휴대폰에 설치합니다.
2. Firefox에서 addons.mozilla.org/android 로 들어갑니다.
3. 이 확장 프로그램이 AMO에 등록된 경우 해당 페이지에서 + 버튼을 눌러 설치합니다.
4. 설치 후 Firefox의 메뉴(⋮) -> 확장 기능(Add-ons/Extensions)에서 활성화되어 있는지 확인합니다.
5. x.com에 로그인합니다.
6. x.com/notifications 를 엽니다.
7. 'liked your repost' 또는 'reposted your repost'가 포함된 알림이 목록에서 사라지는지 확인합니다.

[아직 AMO에 등록되지 않은 개인용 확장 프로그램을 쓰려는 경우]
이 ZIP만으로 Firefox Android에 일반 사용자가 바로 설치할 수 있는 것은 아닙니다.
Firefox Android에서는 확장 프로그램의 배포/서명이 필요할 수 있으므로, 개인적으로 계속 사용할 목적이라면 Mozilla Add-ons(AMO)에 개발자 계정으로 등록하고 배포하는 절차가 필요합니다.

처음 등록할 때는 이 폴더의 manifest.json, content.js, style.css를 그대로 포함한 ZIP을 확장 프로그램 제출 파일로 사용합니다.
AMO의 심사/검토를 거친 뒤 설치 페이지에서 Firefox Android로 추가할 수 있습니다.

[설치 후 테스트]
1. x.com/notifications 로 이동합니다.
2. '공 reposted your repost · Oct 1' 같은 알림이 있으면 사라지는지 확인합니다.
3. 일반적인 'liked your post'나 멘션 알림은 남아 있는지 확인합니다.
4. 알림 목록을 아래로 스크롤해 새 알림이 나타날 때도 필터가 적용되는지 확인합니다.

[삭제/끄기]
Firefox Android 메뉴(⋮) -> 확장 기능에서 해당 확장 프로그램을 선택합니다.
Enabled를 끄면 일시적으로 비활성화할 수 있고, Remove를 누르면 삭제할 수 있습니다.
